import 'package:flutter/material.dart';
import 'package:email_validator/email_validator.dart';
import 'package:fluttertoast/fluttertoast.dart';

final _formkey = GlobalKey<FormState>();

class Page4Column extends StatefulWidget {
  const Page4Column({
    super.key,
  });

  @override
  State<Page4Column> createState() => _Page4ColumnState();
}

class _Page4ColumnState extends State<Page4Column> {
  bool passwordVisible = true;
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  String? _validateName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your name';
    }
    if (value.length < 3) {
      return 'Name should be more then 3 character';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    // String pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
    // RegExp regex = RegExp(pattern);
    if (!EmailValidator.validate(value)) {
      return 'Please enter a valid email';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 8) {
      return 'Password must be at least 8 characters long';
    }
    if (!RegExp(r'[A-Z]').hasMatch(value)) {
      return 'Password must contain at least one uppercase letter';
    }
    if (!RegExp(r'[a-z]').hasMatch(value)) {
      return 'Password must contain at least one lowercase letter';
    }
    if (!RegExp(r'[0-9]').hasMatch(value)) {
      return 'Password must contain at least one number';
    }
    if (!RegExp(r'[!@#$%^&*(),.?":{}|<>]').hasMatch(value)) {
      return 'Password must contain at least one special character';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Container(
          margin: EdgeInsets.fromLTRB(20, 50, 20, 0),
          child: Form(
            key: _formkey,
            child: Center(
              child: Column(
                children: [
                  TextFormField(
                    controller: _nameController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      labelText: 'Name',
                      hintText: 'UserName',
                      icon: Icon(Icons.people),
                    ),
                    autocorrect: true,
                    autofocus: true,
                    validator: _validateName,
                    // onChanged: (value) {
                    //   _formkey.currentWidget
                    // },
                    onChanged: (value){
                      _formkey.currentState!.validate();
                    },
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _emailController,
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      labelText: 'Mail',
                      hintText: 'user@mail.com',
                      icon: Icon(Icons.mail),
                    ),
                    autocorrect: true,
                    autofocus: true,
                    validator: _validateEmail,
                    onChanged: (value) {
                      _formkey.currentState!.validate();
                    },
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: passwordVisible,
                    decoration: passwordDecoration(),
                    keyboardType: TextInputType.visiblePassword,
                    textInputAction: TextInputAction.done,
                    validator: _validatePassword,
                    onChanged: (value) {
                      _formkey.currentState!.validate();
                    },
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                    
                    },
                    child: Text('Submit'),
                  ),
                ],
              ),
            ),
          ),
        )
      ],
    );
  }

  InputDecoration passwordDecoration() {
    return InputDecoration(
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(30),
      ),
      labelText: 'Password',
      hintText: 'Password',
      icon: const Icon(Icons.key),
      suffixIcon: IconButton(
        icon: Icon(passwordVisible ? Icons.visibility : Icons.visibility_off),
        onPressed: () {
          setState(
            () {
              passwordVisible = !passwordVisible;
            },
          );
        },
      ),
      alignLabelWithHint: false,
    );
  }
}
