import 'package:flutter/material.dart';

final _formkey = GlobalKey<FormState>();

class Page5Column extends StatefulWidget {
  const Page5Column({
    super.key,
  });

  @override
  State<Page5Column> createState() => _Page5ColumnState();
}

class _Page5ColumnState extends State<Page5Column> {
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  String? _validateName(String? value) {
    if (value == null || value.isEmpty ) {
      return 'Please enter your name';
    }
    if(value.length<3){
      return 'Name should be more then 3 character';
    }
    return null;
  }

  String? _validateEmail(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your email';
    }
    String pattern =
        r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$';
    RegExp regex = RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Please enter a valid email';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter your password';
    }
    if (value.length < 8) {
      return 'Password must be at least 8 characters long';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formkey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            margin: const EdgeInsets.all(20),
            child: TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                hintText: 'name',
              ),
         validator: _validateName,
              keyboardType: TextInputType.visiblePassword,
              textInputAction: TextInputAction.done,
              onChanged: (value) {
                
        _formkey.currentState!.validate();
              },

            ),
          ),
          Container(
            margin: const EdgeInsets.all(20),
            child: TextFormField(
              controller: _emailController,
              decoration: const InputDecoration(
                hintText: 'Email',
              ),
              keyboardType: TextInputType.visiblePassword,
              textInputAction: TextInputAction.done,
              validator: _validateEmail,
                onChanged: (value) {
                
        _formkey.currentState!.validate();
              },
            ),
          ),
       
        ],
      ),
    );
  }
}
